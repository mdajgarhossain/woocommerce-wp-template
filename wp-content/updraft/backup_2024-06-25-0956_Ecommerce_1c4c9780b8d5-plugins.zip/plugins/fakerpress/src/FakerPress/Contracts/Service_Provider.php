<?php

namespace FakerPress\Contracts;

use FakerPress\ThirdParty\lucatume\DI52\ServiceProvider as DI52_Service_Provider;

abstract class Service_Provider extends DI52_Service_Provider  {
    // Intentionally empty.
}
