<?php

namespace FakerPress\Exceptions;

/**
 * Class Not_Bound_Exception.
 *
 * @since 0.6.4
 *
 * @package FakerPress\Exceptions
 */
class Not_Bound_Exception extends Container_Exception {
	// Intentionally empty.
}
