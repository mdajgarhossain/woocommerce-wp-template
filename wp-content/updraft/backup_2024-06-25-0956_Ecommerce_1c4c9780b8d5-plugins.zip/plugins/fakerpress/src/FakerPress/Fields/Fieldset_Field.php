<?php

namespace FakerPress\Fields;

class Fieldset_Field extends Field_Abstract {
	/**
	 * {@inheritDoc}
	 */
	protected static $slug = 'fieldset';
}
