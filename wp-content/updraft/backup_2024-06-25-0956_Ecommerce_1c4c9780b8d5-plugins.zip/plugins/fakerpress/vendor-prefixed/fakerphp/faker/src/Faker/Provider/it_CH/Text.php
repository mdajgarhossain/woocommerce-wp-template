<?php
/**
 * @license MIT
 *
 * Modified by Gustavo Bordoni on 22-April-2024 using {@see https://github.com/BrianHenryIE/strauss}.
 */

namespace FakerPress\ThirdParty\Faker\Provider\it_CH;

class Text extends \FakerPress\ThirdParty\Faker\Provider\it_IT\Text
{
}
